package com.sandeep.ims.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.sandeep.ims.entity.InventoryEntity;
@Repository
@Component
public interface InventoryRepo extends JpaRepository<InventoryEntity, Integer> {
	@Query("SELECT i FROM inventory i WHERE i.productId = ?1")
	InventoryEntity findById1(int id);
	@Query(value = "UPDATE inventory SET product_name = ?1, description = ?2, working = ?3 WHERE product_id = ?4", nativeQuery = true)
InventoryEntity updateById1(int id);
	@Query(value = "delete from inventory where productId=id", nativeQuery = true)
	public void deleteById1(int id);
	@Query(value = "INSERT INTO Inventory (productName, description, working) VALUES (e.getproductName(),e.getdescription,e.getworking())", nativeQuery = true)
	public void save1(InventoryEntity e);

   
}

