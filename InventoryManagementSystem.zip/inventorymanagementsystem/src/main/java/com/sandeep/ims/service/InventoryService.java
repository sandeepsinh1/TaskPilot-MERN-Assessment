package com.sandeep.ims.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sandeep.ims.entity.InventoryEntity;
import com.sandeep.ims.repository.InventoryRepo;
import com.sandeep.ims.repository.Repo;

@Service
public class InventoryService 
{
	@Autowired(required=true)
	Repo inventoryRepo;

	public String addInventory(InventoryEntity inventory) {
		inventoryRepo.save1(inventory);//save(inventory);
		return "java";
	}

	public InventoryEntity getInventory(int a) {
		return inventoryRepo.findById1(a);//save(inventory);
		
		
	}

	public String deleteInventory(int a)
	{
		 inventoryRepo.deleteById1(a);;//save(inventory);
		 return "datadeleted";
			}	
	public String updateInventory(int a)
	{
		 inventoryRepo.updateById1(a);;//save(inventory);
		 return "updated";
			}	
	
}
