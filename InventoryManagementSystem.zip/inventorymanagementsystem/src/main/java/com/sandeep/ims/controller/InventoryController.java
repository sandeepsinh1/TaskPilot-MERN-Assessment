package com.sandeep.ims.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sandeep.ims.entity.InventoryEntity;
import com.sandeep.ims.service.InventoryService;

@RestController
@RequestMapping("/inventory")
public class InventoryController
{
	 @Autowired
	    private InventoryEntity ie; // ✅ inject the repository
	@Autowired
	 InventoryService inventoryService;

	@GetMapping("/ram")
	String check()
	{
		return "cehk";
	}
	
	 @PostMapping("/addProduct") 
	 public String addInventory(@RequestBody InventoryEntity inventory)
	 {
	 System.out.println(inventory.getDescription());
	 return inventoryService.addInventory(inventory);
	 }
	 
	 @PostMapping("/getInventory/a")
	 public InventoryEntity getInventory(@PathVariable int a )
	 {
	 //System.out.println(inventory.getDescription());
	 return inventoryService.getInventory(a);
	 }
	 @PostMapping("/deleteInventory/a")
	 public String deleteInventory(@PathVariable int a )
	 {
	 //System.out.println(inventory.getDescription());
	 return inventoryService.deleteInventory(a);
	 }
	 @PostMapping("/updateInventory/a")
	 public String updateInventory(@PathVariable int a )
	 {
	 //System.out.println(inventory.getDescription());
	 return inventoryService.updateInventory(a);
	 }
	 

}
