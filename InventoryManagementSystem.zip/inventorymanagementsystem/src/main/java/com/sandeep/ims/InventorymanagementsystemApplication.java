package com.sandeep.ims;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.sandeep.ims.entity.InventoryEntity;

@SpringBootApplication
@EnableJpaRepositories(basePackageClasses = InventoryEntity.class)
public class InventorymanagementsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventorymanagementsystemApplication.class, args);
	}

}
