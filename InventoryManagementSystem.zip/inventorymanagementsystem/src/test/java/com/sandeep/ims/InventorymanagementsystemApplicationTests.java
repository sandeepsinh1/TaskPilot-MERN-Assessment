package com.sandeep.ims;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventorymanagementsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
